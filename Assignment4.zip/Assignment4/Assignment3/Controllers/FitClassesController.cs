﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment3.Models;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3.Controllers
{
    public class FitClassesController : Controller
    {
        public IActionResult Index()
        {
            var cat = new List<FitnessClass>();
            char c1 = 'A';
            int fee = 21;
            int feeCounter = 0;
            for(int i = 185; i < 200; i++)
            {
                var fit = new FitnessClass { classNumber = i, classTitle = "TBD FitnessClass" + c1, classFee = fee };
                cat.Add(fit);
                c1++;
                feeCounter++;
                if(fee == 21)
                {
                    fee++;
                    feeCounter = 0;
                }
                else if(feeCounter >= 3)
                {
                    fee++;
                    feeCounter = 0;
                }
            }
            ViewBag.FitnessClass = cat;
            return View();
        }

        public IActionResult MyClasses(String memId)
        {
            ViewData["memId"] = memId;
            return View();
        }

        public IActionResult Enroll(String id, String classId)
        {
            ViewBag.ID = id;
            ViewBag.classId = classId;
            return View();
        }

        public IActionResult Withdraw()
        {
            ViewBag.Message = "UNDER CONSTRUCTION";
            return View();
        }
    }
}