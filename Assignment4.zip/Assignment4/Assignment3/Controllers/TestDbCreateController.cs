﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment3.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Assignment3.Controllers
{
    public class TestDbCreateController : Controller
    {
        private readonly MembershipContext _context;

        public TestDbCreateController(MembershipContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> ListMembers()
        {
            var members = _context.Members.Include(a => a.membershipType).Include(a => a.membershipStatus);

            
            return View(await members.ToListAsync());
        }

        public async Task<IActionResult> ListMembersOfType(int membershipType)
        {
            var members = _context.Members.Include(a => a.membershipType).Include(a => a.membershipType).Include(a => a.membershipStatus);

            var membersList = members.Where(a => a.membershipType.membershipTypeId == membershipType);

            return View(await members.ToListAsync());
        }
    }
}