﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public class Member
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int memberId { get; set; }
        public string lastName { get; set; }
        public string firstName { get; set; }
        public string streetAddress { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public Int32 zipCode { get; set; }
        public string emailAddress { get; set; }
        public string phoneHome { get; set; }
        public string phoneMobile { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int membershipTypeId { get; set; }
        public string Employer { get; set; }
        public int employerAddressZipCode { get; set; }
        public string employerPhone { get; set; }
        public int membershipStatusId { get; set; }
        public string emergencyContactName { get; set; }
        public string emergencyContactPhone { get; set; }
        public string emergencyContactRelationship { get; set; }
        public  double currentAmountowed { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int primaryLocationId { get; set; }
        public MembershipType membershipType { get; set; }
        public Location primaryLocation { get; set; }
        public MembershipStatus membershipStatus { get; set; }
    }
}
