﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public class FitnessClass
    {
        public String classTitle { get; set; }
        public int classNumber { get; set; }
        public double classFee { get; set; }
    }
}
