﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public class MembershipType
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int membershipTypeId { get; set; }
        public string membershipTypeDescription { get; set; }
        public double membershipMonthlyRate { get; set; }
    }
}
