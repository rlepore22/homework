﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public class Location
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int locationId { get; set; }
        public string locationStreetAddress { get; set;}
        public string locationCity { get; set; }
        public string locationState { get; set; }
        public Int32 lcoationZipCode { get; set; }
        public string locationShortName { get; set; }
        public string locationPhoneNumber { get; set; }
    }
}
