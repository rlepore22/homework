﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public static class DbInitializer
    {
        public static void Initialize(MembershipContext context)
        {
            context.Database.EnsureCreated();

            if(context.Members.Any())
            {
                return;
            }
            context.Members.Add(new Member()
            {
                memberId = 101,
                firstName = "Joe",
                lastName = "Doe",
                streetAddress = "7070 Anywhere Place",
                city = "River Forest",
                state = "IL",
                zipCode = 60305,
                emailAddress = "joedoe@somewhere.com",
                phoneHome = "708-366-3696",
                phoneMobile = "708-998-0873",
                membershipTypeId = 1,
                Employer = "XYZ Firm",
                employerPhone = "708-366-3696",
                membershipStatusId = 1,
                emergencyContactName = "Jane Doe",
                emergencyContactPhone = "708-366-3696",
                emergencyContactRelationship = "Spouse",
                primaryLocationId = 3
            });

            context.Members.Add(new Member()
            {
                memberId = 102,
                firstName = "Herman",
                lastName = "Munster",
                streetAddress = "1313 Mockingbird Lane",
                city = "Mockingbird Heights",
                state = "IL",
                zipCode = 90000,
                emailAddress = "herman@frights.com",
                phoneHome = "310-100-1009",
                phoneMobile = "310-100-1009",
                membershipTypeId = 2,
                Employer = "Gateman Goodbury and Graves",
                employerPhone = "310-100-1109",
                membershipStatusId = 1,
                emergencyContactName = "Lily",
                emergencyContactPhone = "310-100-1009",
                emergencyContactRelationship = "Spouse",
                primaryLocationId = 1
            });

            context.locations.Add(new Location()
            {
                locationId = 1,
                locationShortName = "AZIPPY Schaumburg",
                locationStreetAddress = "1704 E Higgins",
                locationCity = "Schaumburg",
                locationState = "IL",
                lcoationZipCode = 603173,
                locationPhoneNumber = "847-706-559"
            });

            context.locations.Add(new Location()
            {
                locationId = 3,
                locationShortName = "AZIPPY Oak Park",
                locationStreetAddress = "403 N Harlem",
                locationCity = "Oak Park",
                locationState = "IL",
                lcoationZipCode = 603101,
                locationPhoneNumber = "708-445-5460"
            });

            context.membershipStatuses.Add(new MembershipStatus()
            {
                membershipStatusId = 1,
                membershipStatusDescription = "Good standing"
            });

            context.membershipStatuses.Add(new MembershipStatus()
            {
                membershipStatusId = 2,
                membershipStatusDescription = "Banned"
            });

            context.membershipStatuses.Add(new MembershipStatus()
            {
                membershipStatusId = 3,
                membershipStatusDescription = "Suspended"
            });

            context.membershipStatuses.Add(new MembershipStatus()
            {
                membershipStatusId = 4,
                membershipStatusDescription = "Quit"
            });

            context.membershipTypes.Add(new MembershipType()
            {
                membershipTypeId = 1,
                membershipTypeDescription = "Single",
                membershipMonthlyRate = 75.0
            });

            context.membershipTypes.Add(new MembershipType()
            {
                membershipTypeId = 2,
                membershipTypeDescription = "Family",
                membershipMonthlyRate = 160.0
            });

            context.membershipTypes.Add(new MembershipType()
            {
                membershipTypeId = 3,
                membershipTypeDescription = "Social",
                membershipMonthlyRate = 60.0
            });
            context.SaveChanges();
        }
    }
}
