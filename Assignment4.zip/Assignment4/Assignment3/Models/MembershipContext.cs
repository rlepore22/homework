﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment3.Models
{
    public class MembershipContext : DbContext
    {
        public MembershipContext(DbContextOptions<MembershipContext> options) : base(options) { }

        public DbSet<Member> Members { get; set; }
        public DbSet<MembershipType> membershipTypes { get; set; }
        public DbSet<MembershipStatus> membershipStatuses { get; set; }
        public DbSet<Location> locations { get; set; }
    }
}
